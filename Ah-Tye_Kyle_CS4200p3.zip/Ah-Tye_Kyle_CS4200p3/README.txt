-----------HOW TO COMPILE AND FUN FROM THE COMMAND LINE--------

javac Main.java Board.java GameEngine.java GameSimulator.java Minimax.java
java Main.java

The user will be prompted two options:
	1) Player goes first
	2) Computer goes first

The game will begin to play and the user is able to choose the next moves.

Note: GameSimulator is only used for testing purposes.


